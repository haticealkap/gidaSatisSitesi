<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProductImagesController extends Controller
{
    public function index(){
        
    }
    public function store(){

    }
    public function edit(){

    }
    public function destroy(){

    }
}
