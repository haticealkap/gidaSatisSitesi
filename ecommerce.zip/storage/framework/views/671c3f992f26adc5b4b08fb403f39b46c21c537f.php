
<?php echo $__env->make('dashboard.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>



<script type="application/javascript" src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script  src="https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.js"></script>

<?php echo $__env->yieldPushContent('scripts'); ?>
<?php echo $__env->make('dashboard.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ibrah\OneDrive\Masaüstü\ecommerce\resources\views/dashboard/layouts/default.blade.php ENDPATH**/ ?>