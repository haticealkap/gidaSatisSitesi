
<?php $__env->startSection('content'); ?>
    <div class="page-header breadcrumb-wrap">
        <div class="container">
            <div class="breadcrumb">
                <a href="/" rel="nofollow">Anasayfa</a>
                <span></span> Sayfalar
                <span></span> Giriş Yap / Kayıt Ol
            </div>
        </div>
    </div>
    <section class="pt-150 pb-150">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 m-auto">
                    <div class="row">
                        <div class="col-lg-5">
                         
                        </div>
                        <div class="col-lg-1"></div>
                        <div class="col-lg-6">
                            <div class="login_wrap widget-taber-content p-30 background-white border-radius-5">
                                <div class="padding_eight_all bg-white">
                                    <div class="heading_s1">
                                        <h3 class="mb-30">Hesap Oluştur</h3>
                                    </div>
                                    <?php if(isset($errors)): ?>
                                        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    <form method="post" action="/api/v1/users">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <input type="text" required="" name="first_name" placeholder="İsim">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" required="" name="last_name" placeholder="Soyisim">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" required="" name="email" placeholder="Email">
                                        </div>
                                        <div class="form-group">
                                            <input required="" type="password" name="password" placeholder="Şifre">
                                        </div>
                                        <div class="form-group">
                                            <input required="" type="password" name="password" placeholder="Şifre Tekrar">
                                        </div>
                                        <div class="form-group">
                                            <input required="" type="text" name="state" placeholder="Adres">
                                        </div>
                                        <div class="form-group">
                                            <input required="" type="text" name="country" placeholder="Ülke">
                                        </div>
                                        <div class="form-group">
                                            <input required="" type="text" name="phone" placeholder="Telefon">
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-fill-out btn-block hover-up"
                                                name="login">Kaydol &amp; </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ibrah\OneDrive\Masaüstü\ecommerce\resources\views/client/login.blade.php ENDPATH**/ ?>