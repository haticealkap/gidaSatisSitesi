
<?php $__env->startSection('content'); ?>
<div class="page-header breadcrumb-wrap">
    <div class="container">
        <div class="breadcrumb">
            <a href="index.html" rel="nofollow">Anasyafa</a>
            <span></span> Alışveriş
            <span></span> Sepet
        </div>
    </div>
</div>
<section class="mt-50 mb-50">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="table-responsive">
                    <table class="table shopping-summery text-center clean">
                        <thead>
                            <tr class="main-heading">
                                <th scope="col">Görsel</th>
                                <th scope="col">İsim</th>
                                <th scope="col">Ücret</th>
                                <th scope="col">Adet</th>
                                <th scope="col">Toplam Fİyat</th>
                                <th scope="col">Sil</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(session()->has('message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('message')); ?>

                            </div>
                        <?php endif; ?>                            <?php if(isset($sepet)): ?>
                                <?php $__currentLoopData = $sepet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="image product-thumbnail"><img src="<?php echo e(asset('public/images/'.$sep->get_products[0]->image)); ?>" alt="#"></td>
                                    <td class="product-des product-name">
                                        <h5 class="product-name"><a href="shop-product-right.html"><?php echo e($sep->get_products[0]->name); ?></a></h5>
                                        <p class="font-xs"><?php echo e($sep->get_products[0]->content); ?>

                                        </p>
                                    </td>
                                    <td class="price" data-title="Price"><span>₺ <?php echo e($sep->get_products[0]->promotion_price); ?> </span></td>
                                    <td class="text-center" data-title="Stock">
                                        <div class="detail-qty border radius  m-auto">
                                            <span class="qty-val"><?php echo e($sep->piece); ?></span>
                                        </div>
                                    </td>
                                    <td class="text-right" data-title="Cart">
                                        <span><?php echo e($sep->get_products[0]->promotion_price * $sep->piece); ?> ₺</span>
                                    </td>
                                    <td class="action" data-title="Remove"><a href="<?php echo e(url('/api/v1/sepet-del/'.$sep->id)); ?>" class="text-muted"><i class="fi-rs-trash"></i></a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        

                        </tbody>
                    </table>
                </div>
                <div class="cart-action text-end">
                    <a href="/products" class="btn  mr-10 mb-sm-15"><i class="fi-rs-shuffle mr-10"></i>Alışverişe Devam Et</a>
                    <a href="<?php echo e(url('/api/v1/orders/'.auth()->user()->id)); ?>" class="btn "><i class="fi-rs-shopping-bag mr-10"></i>Şiparişi Ver</a>
                </div>
                <div class="divider center_icon mt-50 mb-50"><i class="fi-rs-fingerprint"></i></div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ibrah\OneDrive\Masaüstü\ecommerce\resources\views/client/sepet.blade.php ENDPATH**/ ?>