<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Product;

class Sepet extends Model
{
    use HasFactory;
    protected $collection="sepets";

    public function get_products(){
        return $this->hasMany(Product::class,'id','product_id');
    }
}
