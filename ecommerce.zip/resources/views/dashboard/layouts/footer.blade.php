<footer class="main-footer font-xs">
    <div class="row pb-30 pt-15">
        <div class="col-sm-6">
            <script>
            document.write(new Date().getFullYear())
            </script> ©
        </div>
        <div class="col-sm-6">
            <div class="text-sm-end">
            </div>
        </div>
    </div>
</footer>
</main>
<script src="{{ asset('evara-backend/assets/js/vendors/jquery-3.6.0.min.js')}}"></script>
<script src="{{ asset('evara-backend/assets/js/vendors/bootstrap.bundle.min.js')}}"></script>
<script src="{{ asset('evara-backend/assets/js/vendors/select2.min.js')}}"></script>
<script src="{{ asset('evara-backend/assets/js/vendors/perfect-scrollbar.js')}}"></script>
<script src="{{ asset('evara-backend/assets/js/vendors/jquery.fullscreen.min.js')}}"></script>
<script src="{{ asset('evara-backend/assets/js/vendors/chart.js')}}"></script>
<!-- Main Script -->
<script src="{{ asset('evara-backend/assets/js/main.js')}}" type="text/javascript"></script>
<script src="{{ asset('evara-backend/assets/js/custom-chart.js')}}" type="text/javascript"></script>
</body>
</html>